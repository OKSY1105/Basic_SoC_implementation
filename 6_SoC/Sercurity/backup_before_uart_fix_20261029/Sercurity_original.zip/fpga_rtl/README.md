# CORE-5300 (`XC7Z010CLG400-1`) 스마트 방범 시스템 Verilog RTL

기존 ATmega128 스마트 방범 시스템을 **CORE-5300 FPGA 실습장비(`XC7Z010CLG400-1`, PL `50MHz`)**로 이식한 Verilog RTL 설계 및 검증 파일 모음입니다.

---

## 1. 확정된 시스템 동작 사양 (모드 전환 제거 · 상시 감시)

1. **상시 감시 + 디지털 시계 (`F-01`, `NFR-03`)**:
   - 전원 인가 또는 리셋(`PB0`, `V15`) 시 별도의 모드 전환 스위치 없이 **즉시 상시 초음파 감시 상태**로 동작합니다.
   - 평소 4자리 7-세그먼트(`U12, T12, T10, T11` Active High / `Y16~V13` Active Low)에는 24시간제 디지털 시계(`HH.MM`)를 2ms 다이나믹 스캔으로 표시합니다.
2. **동적 임계 거리 설정 (`F-02`)**:
   - 슬라이드 스위치 4개(`PL SW[3:0]`: `W14, Y14, T16, U17`)로 임계 거리(`threshold_cm`)를 실시간 설정합니다.
   - 계산식: `threshold_cm = 10 + (SW[3:0] × 5)` cm (`10cm ~ 85cm`, `5cm` 단위)
3. **50ms 초음파 거리 측정 + 5회 이동평균 필터 (`F-02`, `NFR-01`, `NFR-05`)**:
   - `50ms` 주기(`NFR-01` 100ms 이내 충족)로 `Trig`(`J20`)에 `10us` 펄스를 출력하고 `Echo`(`H20`) 폭을 `1us` 단위로 측정(`/ 58` → cm 환산)합니다.
   - 최근 **5회 유효 측정값의 이동평균(`sum / 5`)**으로 침입 여부를 판정하여 단발성 센서 노이즈로 인한 오경보를 방지합니다(예외 시나리오 3 충족).
4. **복합 경보 출력 및 알람 Latch 유지 (`F-03`)**:
   - `distance_cm <= threshold_cm` 감지 시 **`alert_flag = 1`로 고정(Latch)**되며, 침입자가 물러나 거리가 다시 멀어져도 스스로 꺼지지 않습니다.
   - 경보 작동 시:
     - **PL LED 0~3 (`P15, P16, N20, P20`)**: `250ms` 주기로 전체 점멸(`4'b1111` ↔ `4'b0000`)
     - **부저 (`L19`)**: 경보음 출력
     - **DC 모터 (`DRV8848`: `IN1=K14`, `IN2=J14`, `nSleep=L14`)**: `nSleep=1`, `IN2`에 `1kHz` PWM(듀티비 75%) 구동
5. **알람 해제 수단 (`F-04`, `F-05`, `NFR-02`, `NFR-04`)**:
   - **로컬 해제 (`1x4 정전식 터치 키패드 TTP224`: `L15, K16, J16, M17`)**:
     - 각 키에 **20ms 하드웨어 디바운서(`NFR-04`)** 및 상승 엣지 검출기를 적용했습니다.
     - `1번(L15) → 2번(K16) → 3번(J16) → 4번(M17)` 순서로 누르면 단계별로 `PW:STEP1~3`을 송신하고 4단계 완료 시 알람을 해제(`PW:OK_NRM`)한 뒤 상시 감시로 복귀합니다.
     - 잘못된 순서로 입력하면 즉시 `pw_step = 0`으로 초기화하고 알람을 유지하며 PC로 `PW:ERROR`를 전송합니다(예외 시나리오 1 충족).
   - **원격 해제 (PC Python GUI `UART1_Repeater_GUI.py` 연동)**:
     - `[SOF(0xAA)] + [TYPE(1B)] + [LEN(1B)] + [PAYLOAD] + [CRC8(1B)]` 프레임 규격과 1바이트 XOR 체크섬(`NFR-02`)을 하드웨어로 구현했습니다.
     - PC에서 `"stop"`(또는 `"STOP"`) 명령 수신 시 CRC8이 일치하면 즉시 알람을 해제하고 `ACK("OK")` 및 `DATA("PW:OK_PC")`를 반환합니다.
     - CRC8 오류 시 명령을 무시하고 `ERR("E:CRC")` 프레임을 반환합니다(예외 시나리오 2 충족).

---

## 2. 모듈 구성 및 파일 목록

| 파일명 | 역할 | 관련 요구사항 |
| :--- | :--- | :--- |
| [security_top.v](<security_top.v>) | 최상위 통합 모듈 (`XC7Z010CLG400-1` 포트 매핑) | 전체 |
| [clk_div.v](<clk_div.v>) | `50MHz` 클럭 분주기 (`1us`, `2ms`, `50ms`, `1s` 틱 생성) | `F-01`, `NFR-01` |
| [debounce_edge.v](<debounce_edge.v>) | 2-FF 동기화기 + `20ms` 하드웨어 디바운서 + 원샷 엣지 검출기 | `NFR-04` |
| [clock_fnd_ctrl.v](<clock_fnd_ctrl.v>) | 24시간제 디지털 시계(`HH:MM`) 및 4자리 7-Segment 다이나믹 컨트롤러 | `F-01`, `NFR-03` |
| [ultrasonic_ctrl.v](<ultrasonic_ctrl.v>) | `50ms` 주기 초음파 거리 측정기 + **5회 이동평균 필터** | `F-02`, `NFR-01`, `NFR-05` |
| [security_fsm.v](<security_fsm.v>) | 상시 감시·알람 Latch·터치 키패드 비밀번호 FSM·복합 경보 제어기 | `F-02`, `F-03`, `F-05` |
| [uart_frame_ctrl.v](<uart_frame_ctrl.v>) | `9600bps` UART RX/TX 및 `0xAA` 프레임/CRC8 파서·패킷 빌더 | `F-04`, `NFR-02` |
| [security_core5300.xdc](<security_core5300.xdc>) | CORE-5300 보드 핀 제약 파일 (`LVCMOS33`, 34개 물리 핀 고정, `uart_rx` 내부 `PULLUP`) | 하드웨어 핀맵 |
| [tb_security_top.v](<tb_security_top.v>) | **1단계(Behavioral RTL Sim)** 전 요구사항(Check 1~8) 자가 검증 테스트벤치 | 1단계 기능 시뮬레이션 |
| [tb_post_synth.v](<tb_post_synth.v>) | **3단계(Post-Synthesis Gate-Level Sim)** 최상위 물리 핀 전용 넷리스트 검증 테스트벤치 | 3단계 게이트 레벨 시뮬레이션 |
| [create_vivado_project.tcl](<create_vivado_project.tcl>) | Vivado 2024.2 프로젝트 자동 생성 스크립트 | 프로젝트 생성 |
| [open_sim_gui.tcl](<open_sim_gui.tcl>) | Vivado 2024.2 GUI 실행 · 6대 기능별 파형 그룹 구성 · 전 구간 시뮬레이션 자동 실행 스크립트 | GUI 파형 확인 |
| [run_vivado_verify.tcl](<run_vivado_verify.tcl>) | Vivado 2024.2 2단계(합성·구현·타이밍·비트스트림) & 3단계 넷리스트 자동 검증 스크립트 | 배치 검증 |

---

## 3. 5단계 검증 절차 및 Vivado 2024.2 실측 검증 결과

| 단계 | 검증 항목 | 사용 파일 / 도구 | 실측 결과 |
| :--- | :--- | :--- | :--- |
| **1단계** | **RTL 기능 시뮬레이션 (Behavioral Sim)** | [tb_security_top.v](<tb_security_top.v>) (`xvlog` / `xelab` / `xsim`) | **PASS** (`ALL 8 CHECKS PASSED, 0 errors`) |
| **2단계** | **Vivado 합성 · 구현 · 타이밍 · 비트스트림 생성** | [run_vivado_verify.tcl](<run_vivado_verify.tcl>) (`synth_design` → `route_design` → `write_bitstream`) | **PASS** (`LUT 863(4.90%)`, `FF 599(1.70%)`, `Latch 0`, **`WNS +5.067ns`**, `0 DRC error`) |
| **3단계** | **합성 후 게이트 레벨 시뮬레이션 (Post-Synthesis Sim)** | [tb_post_synth.v](<tb_post_synth.v>) + `UNISIM` 게이트 넷리스트 (`glbl`) | **PASS** (`ALL 5 GATE-LEVEL CHECKS PASSED`, `uart_tx` 51개 `0xAA` 프레임 CRC8 일치) |
| **4단계** | **CORE-5300 보드 단독 하드웨어 검증** | `security_top.bit` 다운로드 + 보드 실물 스위치/센서/터치/모터 | 보드 연결 시 즉시 수행 가능 |
| **5단계** | **PC Python GUI 통합 검증** | [../pc_gui/UART1_Repeater_GUI.py](<../pc_gui/UART1_Repeater_GUI.py>) (`9600bps`) | 보드 연결 시 즉시 수행 가능 |

> **3단계(Post-Synthesis Simulation) 핵심 주의사항**:
> 합성 후 생성되는 게이트 레벨 넷리스트(`security_top`)는 내부 계층 신호(`dut.alert_flag` 등)와 최상위 `parameter` 오버라이드가 제거되고 Xilinx `UNISIM` 프리미티브(`LUT`, `FDRE`, `CARRY4`, `IBUF`, `OBUF`)로 변환됩니다. 따라서 3단계 합성 후 시뮬레이션에서는 반드시 **최상위 물리 핀만 제어·관측하고 `uart_tx` 직렬 파형을 디코딩하는 전용 테스트벤치([tb_post_synth.v](<tb_post_synth.v>))**를 시뮬레이션 Top으로 설정해야 합니다.

---

## 4. Vivado 프로젝트 생성 및 보드 연결 방법

### 4-1. Vivado 프로젝트 자동 생성

Vivado 실행 후 하단 **Tcl Console**에서 아래 두 줄을 실행하면 프로젝트 생성과 파일 등록이 한 번에 완료됩니다.

```tcl
cd C:/Antigravity_project/Sercurity/fpga_rtl
source create_vivado_project.tcl
```

### 4-2. 보드 하드웨어 스위치 설정 및 USB-UART 연결 참고

1. **보드 물리 스위치 2곳 확인**:
   - **카메라 vs 센서/모터 선택 스위치**: 반드시 **센서/모터** 방향으로 설정
   - **DC 모터 vs 스텝 모터 선택 스위치**: 반드시 **DC 모터** 방향으로 설정
2. **PC ↔ CORE-5300 보드 USB-UART 케이블 연결 참고**:
   - CORE-5300 보드의 내장 USB-UART 포트는 Zynq 칩의 **PS(ARM) 영역 핀(`MIO 14, 15`)**에 배선되어 있습니다(교재 **학습 5-1, p.319**).
   - 순수 PL 프로젝트만으로 바로 시험할 때는 [security_core5300.xdc](<security_core5300.xdc>)의 예비 PL 핀(`G15` RX [`PULLUP true`], `G14` TX)에 USB-TTL을 연결하거나, 보드 내장 USB 케이블(`MIO 14, 15`)을 그대로 쓸 때는 Vivado Block Design에서 Zynq7 PS IP의 UART 브릿지를 연결하여 사용합니다.
   - PC에서는 [../pc_gui/UART1_Repeater_GUI.py](<../pc_gui/UART1_Repeater_GUI.py>)를 실행하여 실시간 거리/임계거리 모니터링과 `STOP` 원격 해제를 수행합니다.
