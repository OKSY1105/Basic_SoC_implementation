@echo off
echo ==============================================================================
echo  Downloading FPGA Bitstream and ARM UART Bridge to CORE-5300 via JTAG...
echo ==============================================================================
"C:\Xilinx\Vitis\2024.2\bin\xsdb.bat" run_jtag.tcl
pause
