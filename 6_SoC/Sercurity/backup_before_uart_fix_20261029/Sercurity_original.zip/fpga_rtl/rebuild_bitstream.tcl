open_project C:/Antigravity_project/Sercurity/fpga_rtl/zynq_soc_proj/zynq_soc_proj.xpr

# Add new source files if not already present
add_files -norecurse C:/Antigravity_project/Sercurity/fpga_rtl/lcd_ctrl.v
update_compile_order -fileset sources_1

# Rebuild Synthesis and Implementation with bitstream
reset_run synth_1
launch_runs synth_1 -jobs 6
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
    puts "ERROR: Synthesis failed!"
    exit 1
}

launch_runs impl_1 -to_step write_bitstream -jobs 6
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] != "100%"} {
    puts "ERROR: Implementation failed!"
    exit 1
}

file copy -force C:/Antigravity_project/Sercurity/fpga_rtl/zynq_soc_proj/zynq_soc_proj.runs/impl_1/security_top_zynq.bit C:/Antigravity_project/Sercurity/fpga_rtl/security_top_zynq.bit
puts "SUCCESS: Updated bitstream copied to C:/Antigravity_project/Sercurity/fpga_rtl/security_top_zynq.bit"
exit 0
