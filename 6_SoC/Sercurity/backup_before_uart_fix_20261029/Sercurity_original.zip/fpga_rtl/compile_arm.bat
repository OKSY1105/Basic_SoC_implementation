@echo off
setlocal enabledelayedexpansion

set GCC="C:\Xilinx\Vitis\2024.2\gnu\aarch32\nt\gcc-arm-none-eabi\bin\arm-none-eabi-gcc.exe"

echo === Assembling startup.S ===
%GCC% -mcpu=cortex-a9 -c startup.S -o startup.o
if %ERRORLEVEL% neq 0 (
    echo Error assembling startup.S!
    exit /b 1
)

echo === Compiling uart_bridge.c ===
%GCC% -mcpu=cortex-a9 -O2 -c uart_bridge.c -o uart_bridge.o
if %ERRORLEVEL% neq 0 (
    echo Error compiling uart_bridge.c!
    exit /b 1
)

echo === Linking uart_bridge.elf ===
%GCC% -mcpu=cortex-a9 -nostdlib -Wl,-T -Wl,lscript_mini.ld startup.o uart_bridge.o -o uart_bridge.elf
if %ERRORLEVEL% neq 0 (
    echo Error linking uart_bridge.elf!
    exit /b 1
)

echo === SUCCESS: Clean Baremetal uart_bridge.elf generated! ===
dir uart_bridge.elf
exit /b 0
