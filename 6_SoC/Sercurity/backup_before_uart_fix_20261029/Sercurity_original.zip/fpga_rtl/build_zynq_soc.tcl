# ==============================================================================
# Build Script for CORE-5300 Zynq SoC Smart Security System
# Target Device: XC7Z010CLG400-1
# Vivado Version: 2024.2
# ==============================================================================

set proj_name "zynq_soc_proj"
set proj_dir  [file normalize "./${proj_name}"]
set part      "xc7z010clg400-1"

# 1. Create Project
if {[file exists $proj_dir]} {
    file delete -force $proj_dir
}
create_project $proj_name $proj_dir -part $part

# 2. Create Block Design (zynq_sys)
create_bd_design "zynq_sys"

# Add Processing System 7 IP
set ps7 [create_bd_cell -type ip -vlnv xilinx.com:ip:processing_system7:5.5 ps7]

set_property -dict [list \
    CONFIG.PCW_UART0_PERIPHERAL_ENABLE {1} \
    CONFIG.PCW_UART0_UART0_IO {MIO 14 .. 15} \
    CONFIG.PCW_UART1_PERIPHERAL_ENABLE {1} \
    CONFIG.PCW_UART1_UART1_IO {EMIO} \
    CONFIG.PCW_USE_M_AXI_GP0 {0} \
    CONFIG.PCW_FPGA0_PERIPHERAL_FREQMHZ {50} \
] $ps7

# Connect EMIO UART1 ports to BD external ports
create_bd_port -dir O UART1_TX_0
create_bd_port -dir I UART1_RX_0
connect_bd_net [get_bd_pins ps7/UART1_TX] [get_bd_ports UART1_TX_0]
connect_bd_net [get_bd_pins ps7/UART1_RX] [get_bd_ports UART1_RX_0]

# Connect PL Clock (50MHz)
create_bd_port -dir O FCLK_CLK0_0
connect_bd_net [get_bd_pins ps7/FCLK_CLK0] [get_bd_ports FCLK_CLK0_0]

# Connect Hard Silicon DDR & FIXED_IO
make_bd_intf_pins_external [get_bd_intf_pins ps7/DDR]
make_bd_intf_pins_external [get_bd_intf_pins ps7/FIXED_IO]

validate_bd_design
save_bd_design

# 3. Generate Wrapper for BD
set bd_file [get_files [get_property FILE_NAME [current_bd_design]]]
generate_target all $bd_file
set wrapper_file [make_wrapper -files $bd_file -top]
add_files -norecurse $wrapper_file

# 4. Add Custom Verilog Design Files
add_files -norecurse [list \
    [file normalize "./clk_div.v"] \
    [file normalize "./debounce_edge.v"] \
    [file normalize "./clock_fnd_ctrl.v"] \
    [file normalize "./ultrasonic_ctrl.v"] \
    [file normalize "./security_fsm.v"] \
    [file normalize "./uart_frame_ctrl.v"] \
    [file normalize "./security_top.v"] \
    [file normalize "./security_top_zynq.v"] \
]

# 5. Add Constraints File
add_files -fileset constrs_1 -norecurse [file normalize "./security_core5300_zynq.xdc"]

# 6. Set Top Module
set_property top security_top_zynq [current_fileset]
update_compile_order -fileset sources_1

# 7. Run Synthesis
puts "=== Starting Synthesis ==="
launch_runs synth_1 -jobs 4
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
    puts "ERROR: Synthesis failed!"
    exit 1
}

# 8. Run Implementation & Generate Bitstream
puts "=== Starting Implementation & Bitstream Generation ==="
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1
if {[get_property PROGRESS [get_runs impl_1]] != "100%"} {
    puts "ERROR: Implementation / Bitstream generation failed!"
    exit 1
}

# 9. Copy Bitstream & Export Hardware (XSA)
set bit_src [get_files -of_objects [get_runs impl_1] *.bit]
if {[file exists $bit_src]} {
    file copy -force $bit_src [file normalize "./security_top_zynq.bit"]
    puts "SUCCESS: Bitstream copied to [file normalize ./security_top_zynq.bit]"
}

write_hw_platform -fixed -include_bit -force -file [file normalize "./security_top_zynq.xsa"]
puts "SUCCESS: Hardware XSA exported to [file normalize ./security_top_zynq.xsa]"

puts "=== ALL BUILD STEPS COMPLETED SUCCESSFULLY! ==="
exit 0
